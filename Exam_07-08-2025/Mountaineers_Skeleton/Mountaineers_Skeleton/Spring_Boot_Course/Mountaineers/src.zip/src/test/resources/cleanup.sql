TRUNCATE TABLE countries;
TRUNCATE TABLE mountains;
TRUNCATE TABLE mountaineers;
