insert into mountains (id, name, elevation,eletav , hard_to_reach, country_id)
values    (1, 'Mount Vesuvius', 1281, 'LOW', true, 1),
          (2, 'Mauna Loa', 4169, 'HIGH', true, 2),
          (3, 'Mount Fuji', 3776, 'MEDIUM', false, 3),
          (4, 'Mount St. Helens', 2549, 'MEDIUM', false, 4);