package softuni.exam.models.entity.enums;

public enum ElevationCategory {

    LOW, MEDIUM, HIGH

    }
